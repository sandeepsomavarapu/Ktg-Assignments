package com.productmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productmanagement.dao.ProductDao;
import com.productmanagement.model.Product;

@Service("empservice")
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao dao ;

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {

		return dao.updateProduct(product);
	}

	@Override
	public String removeProduct(int productId) {

		return dao.removeProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return dao.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return dao.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsInBetween(int intialProductPrice, int finalProductPrice) {
		// TODO Auto-generated method stub
		return dao.getAllProductsInBetween(intialProductPrice, finalProductPrice);
	}

	@Override
	public List<Product> getAllProductsByname(String productName) {
		// TODO Auto-generated method stub
		return dao.getAllProductsByname(productName);
	}

}
