package com.ktg.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication//@Configuration,@EnableAutoConfiguration,@ComponentScan
public class SpringBootKtgDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootKtgDemoApplication.class, args);
	}

}
