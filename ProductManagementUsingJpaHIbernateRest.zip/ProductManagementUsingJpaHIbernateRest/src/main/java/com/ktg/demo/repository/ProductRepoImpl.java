package com.ktg.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ktg.demo.entity.Product;

@Repository
@Transactional
public class ProductRepoImpl implements ProductRepo {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addProduct(Product product) {

		entityManager.persist(product);

		return "Product Saved Successfully";
	}

	@Override
	public String updateProduct(Product product) {

		entityManager.merge(product);

		return "Product Updated Successfully";
	}

	@Override
	public String removeProduct(int productId) {

		entityManager.remove(entityManager.find(Product.class, productId));

		return "Product Removed Successfully";

	}

	@Override
	public Product getProduct(int productId) {

		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {

		TypedQuery<Product> products = entityManager.createQuery("select p from Product p", Product.class);

		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsInBetween(int intialProductPrice, int finalProductPrice) {
		TypedQuery<Product> products = entityManager
				.createQuery("select p from Product p where p.productPrice between ?1 and ?2", Product.class);
		products.setParameter(1, intialProductPrice);
		products.setParameter(2, finalProductPrice);
		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsByname(String productName) {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p where p.productName=?1",
				Product.class);
		products.setParameter(1, productName);
		return products.getResultList();
	}

}
