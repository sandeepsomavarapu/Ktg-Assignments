package com.ktg.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ktg.demo.entity.Product;
import com.ktg.demo.service.ProductService;

@RestController
@RequestMapping("/products") //
public class ProductController {
	@Autowired
	ProductService service;

	@GetMapping("/sayhello") // http://localhost:1234/products/sayhello
	public String helloMessage() {
		return "Welcome To SpringBoot Rest";
	}

	@PostMapping("/insertProduct") // http://localhost:1234/products/insertProduct
	public String addProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/updateProduct") // http://localhost:1234/products/updateProduct
	public String editProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/removeProduct/{id}") // http://localhost:1234/products/removeProduct/1
	public String deleteProduct(@PathVariable("id") int productId) {
		return service.removeProduct(productId);
	}

	@GetMapping("/getProductById/{id}") // http://localhost:1234/products/getProductById/1
	public Product getProduct(@PathVariable("id") int productId) {
		return service.getProduct(productId);
	}

	@GetMapping("/getAllProducts") // http://localhost:1234/products/getAllProducts
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}

	@GetMapping("/getAllProductsInBetween/{min}/{max}") // http://localhost:1234/products/getAllProductsInBetween/1000/2000
	public List<Product> getAllProducts(@PathVariable("min") int minPrice, @PathVariable("max") int maxPrice) {
		return service.getAllProductsInBetween(minPrice, maxPrice);
	}

	@GetMapping("/getAllProductsByName/{pname}") // http://localhost:1234/products/getAllProductsByName/lenovo
	public List<Product> getAllProductsByname(@PathVariable("pname") String productName) {
		return service.getAllProductsByname(productName);
	}

}
