package com.ktg.demo.repository;

import java.util.List;

import com.ktg.demo.entity.Product;

public interface ProductRepo {
	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String removeProduct(int productId);

	public abstract Product getProduct(int productId);

	public abstract List<Product> getAllProducts();

	public abstract List<Product> getAllProductsInBetween(int intialProductPrice, int finalProductPrice);

	public abstract List<Product> getAllProductsByname(String productName);
}
