package com.ktg.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagementUsingJpaHIbernateRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagementUsingJpaHIbernateRestApplication.class, args);
	}

}
