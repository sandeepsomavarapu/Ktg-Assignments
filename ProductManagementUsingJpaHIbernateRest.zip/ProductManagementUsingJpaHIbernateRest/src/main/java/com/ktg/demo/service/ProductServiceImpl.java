package com.ktg.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktg.demo.entity.Product;
import com.ktg.demo.repository.ProductRepo;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo dao;

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {

		return dao.updateProduct(product);
	}

	@Override
	public String removeProduct(int productId) {

		return dao.removeProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return dao.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return dao.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsInBetween(int intialProductPrice, int finalProductPrice) {
		// TODO Auto-generated method stub
		return dao.getAllProductsInBetween(intialProductPrice, finalProductPrice);
	}

	@Override
	public List<Product> getAllProductsByname(String productName) {
		// TODO Auto-generated method stub
		return dao.getAllProductsByname(productName);
	}
}
