package com.productmanagement.service;

import java.util.List;
import java.util.Set;

import com.productmanagement.dao.ProductDao;
import com.productmanagement.dao.ProductDaoImpl;
import com.productmanagement.model.Product;

public class ProductServiceImpl implements ProductService {
	ProductDao dao = new ProductDaoImpl();

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {

		return dao.updateProduct(product);
	}

	@Override
	public String removeProduct(int productId) {

		return dao.removeProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return dao.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return dao.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsInBetween(int intialProductPrice, int finalProductPrice) {
		// TODO Auto-generated method stub
		return dao.getAllProductsInBetween(intialProductPrice, finalProductPrice);
	}

	@Override
	public List<Product> getAllProductsByname(String productName) {
		// TODO Auto-generated method stub
		return dao.getAllProductsByname(productName);
	}

}
