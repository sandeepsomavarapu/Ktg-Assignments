package com.productmanagement.dao;

import java.util.List;
import java.util.Set;

import com.productmanagement.model.Product;

public interface ProductDao {
	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String removeProduct(int productId);

	public abstract Product getProduct(int productId);

	public abstract List<Product> getAllProducts();

	void beginTransaction();

	void commitTransaction();

	public abstract List<Product> getAllProductsInBetween(int intialProductPrice, int finalProductPrice);

	public abstract List<Product> getAllProductsByname(String productName);
}
