package com.productmanagement.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.productmanagement.model.Product;

public class ProductDaoImpl implements ProductDao {
	EntityManager entityManager = JPAUtil.getEntityManager();

	@Override
	public String addProduct(Product product) {
		beginTransaction();
		entityManager.persist(product);
		commitTransaction();
		return "Product Saved Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		beginTransaction();
		entityManager.merge(product);
		commitTransaction();
		return "Product Updated Successfully";
	}

	@Override
	public String removeProduct(int productId) {
		beginTransaction();
		entityManager.remove(entityManager.find(Product.class, productId));
		commitTransaction();
		return "Product Removed Successfully";

	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public Product getProduct(int productId) {

		return entityManager.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {

		TypedQuery<Product> products = entityManager.createQuery("select p from Product p", Product.class);

		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsInBetween(int intialProductPrice, int finalProductPrice) {
		TypedQuery<Product> products = entityManager
				.createQuery("select p from Product p where p.productPrice between ?1 and ?2", Product.class);
		products.setParameter(1, intialProductPrice);
		products.setParameter(2, finalProductPrice);
		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsByname(String productName) {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p where p.productName=?1",
				Product.class);
		products.setParameter(1, productName);
		return products.getResultList();
	}

}
