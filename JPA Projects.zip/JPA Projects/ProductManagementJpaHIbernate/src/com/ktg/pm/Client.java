package com.ktg.pm;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
	public static void main(String[] args) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("product");
		EntityManager entitymanager = emfactory.createEntityManager();
		entitymanager.getTransaction().begin(); // persist()-->insert,merge()->update,remove()-->delete,find()
		Product product=new Product("dell", 33000, "laptop",20);
		entitymanager.persist(product);//ORM

	//	Product product = entitymanager.find(Product.class, 123);
	//	System.out.println(product);
//		product.setProductPrice(43000);
//		entitymanager.merge(product);
		
		//entitymanager.remove(product);
		entitymanager.getTransaction().commit();
	}
}
