package com.ktg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("uname");
		String password = req.getParameter("pass");
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		// create the connection
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ktg", "root", "rpsconsulting");
		// create the statement
		PreparedStatement stmt = conn.prepareStatement("select * from gmail where username=? and password=?");
		// execute the query DDL-->execute(),DML-->executeUpdate(),DRL,-->executeQuery
			stmt.setString(1,username);
			stmt.setString(2, password);
		ResultSet result = stmt.executeQuery();
		
		if(result.next())
		{
			out.print("LOGIN SUCCESS");
		}
		else
		{
			out.print("Login Failed .....");
			RequestDispatcher rd=req.getRequestDispatcher("registeration.html");
			rd.include(req,resp);
			
		}
		// close the connection
		conn.close();
	
		}catch(Exception exception)
		{
			System.out.println(exception);
		}
		
		
		
	}

}
