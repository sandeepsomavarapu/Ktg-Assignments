package com.productmanagement.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import com.productmanagement.model.Product;

public class ProductDaoImpl implements ProductDao {
	HashMap<Integer, Product> products = new HashMap<Integer, Product>();

	@Override
	public String addProduct(Product product) {
		products.put(product.getProductId(), product);
		return "Product Saved Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		products.put(product.getProductId(), product);
		return "Product Updated Successfully";
	}

	@Override
	public String removeProduct(int productId) {
		products.remove(productId);
		return "Product Removed Successfully";
	}

	@Override
	public Product getProduct(int productId) {

		return products.get(productId);
	}

	@Override
	public Set<Product> getAllProducts() {
		Set<Product> products1 = new HashSet<Product>();
		Set<Entry<Integer, Product>> entries = products.entrySet();
		Iterator<Entry<Integer, Product>> itr = entries.iterator();
		while (itr.hasNext()) {
			Entry<Integer, Product> entry = itr.next();
			products1.add(entry.getValue());
		}
		return products1;
	}

}
