package com.productmanagement.ui;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.productmanagement.model.Product;
import com.productmanagement.service.ProductService;
import com.productmanagement.service.ProductServiceImpl;

public class ProductClient {

	public static void main(String[] args) {
		int productId;
		String productName;
		int productPrice;
		String productDesc;
		int productQuantity;
		Scanner scan = new Scanner(System.in);
		ProductService service = new ProductServiceImpl();
		while (true) {
			System.out.println("****************Product Management****************");
			System.out.println("1.Add Product");
			System.out.println("2.Update Product");
			System.out.println("3.Delete Product");
			System.out.println("4.Get Product");
			System.out.println("5.GetAll Products");
			System.out.println("6.Exit");

			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Detials To Save Product");
				System.out.println("enter productid:");
				productId = scan.nextInt();
				System.out.println("enter productName:");
				productName = scan.next();
				System.out.println("enter productPrice:");
				productPrice = scan.nextInt();
				System.out.println("enter productDesc:");
				productDesc = scan.next();
				System.out.println("enter productQuantity:");
				productQuantity = scan.nextInt();
				Product product = new Product(productId, productName, productPrice, productDesc, productQuantity);
				System.out.println(service.addProduct(product));
				break;
			case 2:
				System.out.println("Enter Detials To Update Product");
				System.out.println("enter Exsisting productid:");
				productId = scan.nextInt();
				System.out.println("enter productName:");
				productName = scan.next();
				System.out.println("enter productPrice:");
				productPrice = scan.nextInt();
				System.out.println("enter productDesc:");
				productDesc = scan.next();
				System.out.println("enter productQuantity:");
				productQuantity = scan.nextInt();
				Product product1 = new Product(productId, productName, productPrice, productDesc, productQuantity);
				System.out.println(service.updateProduct(product1));
				break;
			case 3:
				System.out.println("enter Exsisting productid:");
				productId = scan.nextInt();
				System.out.println(service.removeProduct(productId));
				break;
			case 4:
				System.out.println("enter Exsisting productid:");
				productId = scan.nextInt();
				System.out.println(service.getProduct(productId));

				break;
			case 5:
				Set<Product> products = service.getAllProducts();
				Iterator<Product> itr = products.iterator();
				while (itr.hasNext()) {
					System.out.println(itr.next());
				}

				break;
			default:
				scan.close();
				System.out.println("Thank You !!!!!");
				System.exit(0);
				break;
			}
		}
	}

}