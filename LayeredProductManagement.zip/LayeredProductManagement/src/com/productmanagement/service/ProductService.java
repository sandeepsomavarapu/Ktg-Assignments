package com.productmanagement.service;

import java.util.Set;

import com.productmanagement.model.Product;

public interface ProductService {
	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String removeProduct(int productId);

	public abstract Product getProduct(int productId);

	public abstract Set<Product> getAllProducts();

}
