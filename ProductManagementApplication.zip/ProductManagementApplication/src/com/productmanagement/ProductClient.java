package com.productmanagement;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class ProductClient {

	public static void main(String[] args) {
		int productId;
		String productName;
		int productPrice;
		String productDesc;
		int productQuantity;
		HashMap<Integer, Product> products = new HashMap<Integer, Product>();
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("****************Product Management****************");
			System.out.println("1.Add Product");
			System.out.println("2.Update Product");
			System.out.println("3.Delete Product");
			System.out.println("4.Get Product");
			System.out.println("5.GetAll Products");
			System.out.println("6.Exit");

			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Detials To Save Product");
				System.out.println("enter productid:");
				productId = scan.nextInt();
				System.out.println("enter productName:");
				productName = scan.next();
				System.out.println("enter productPrice:");
				productPrice = scan.nextInt();
				System.out.println("enter productDesc:");
				productDesc = scan.next();
				System.out.println("enter productQuantity:");
				productQuantity = scan.nextInt();
				Product product = new Product(productId, productName, productPrice, productDesc, productQuantity);
				products.put(productId, product);
				System.out.println("Product Added Successfully");
				break;
			case 2:
				System.out.println("Enter Detials To Save Product");
				System.out.println("enter Exsisting productid:");
				productId = scan.nextInt();
				System.out.println("enter productName:");
				productName = scan.next();
				System.out.println("enter productPrice:");
				productPrice = scan.nextInt();
				System.out.println("enter productDesc:");
				productDesc = scan.next();
				System.out.println("enter productQuantity:");
				productQuantity = scan.nextInt();
				Product product1 = new Product(productId, productName, productPrice, productDesc, productQuantity);
				products.put(productId, product1);
				System.out.println("Product Updated Successfully");
				break;
			case 3:
				System.out.println("enter Exsisting productid:");
				productId = scan.nextInt();
				products.remove(productId);
				System.out.println("Product Deleted Successfully");
				break;
			case 4:
				System.out.println("enter Exsisting productid:");
				productId = scan.nextInt();
				Product prod = products.get(productId);
				System.out.println(prod);

				break;
			case 5:
				Set<Integer> keys = products.keySet();
				Iterator<Integer> itr = keys.iterator();
				while (itr.hasNext()) {
					System.out.println(products.get(itr.next()));
				}
				break;
			default:
				System.out.println("Thank You !!!!!");
				System.exit(0);
				break;
			}
		}
	}

}
