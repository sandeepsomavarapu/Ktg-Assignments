package com.vehicleloanapplication.service;

 

import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.UserRegistrationEntity;

 

public interface LogoutService {
    
    // USED TO LOGOUT FOR USER
    public UserRegistrationEntity logout(UserRegistrationEntity userbasic) throws RecordNotFoundException;
    
}