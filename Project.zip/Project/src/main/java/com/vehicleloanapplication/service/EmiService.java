package com.vehicleloanapplication.service;

public interface EmiService {
	public double EMICalculate(double loanAmount,int terminYears,double interestRate);
	

}