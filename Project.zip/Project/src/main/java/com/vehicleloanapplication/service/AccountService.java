package com.vehicleloanapplication.service;
    import java.util.ArrayList;
    import java.util.List;

 


    import com.vehicleloanapplication.exceptions.RecordNotFoundException;
    import com.vehicleloanapplication.model.AccountEntity;

 


    public interface AccountService {
        public AccountEntity getAccountByEmail(String email) throws RecordNotFoundException;
        public List<AccountEntity> AddAccount(AccountEntity account) throws RecordNotFoundException;
        public List<AccountEntity> UpdateAccount(AccountEntity account)throws RecordNotFoundException;
    
    }
 


