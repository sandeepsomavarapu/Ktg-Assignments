package com.vehicleloanapplication;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@ComponentScan(basePackages="com.vehicleloanapplication")
public class ProjectApplication {

	

	public static void main(String[] args) {
		Logger log = Logger.getLogger(ProjectApplication.class);
		log.info("Info level log message");
		log.debug("Debug level log message");
		log.error("Error level log message");
		SpringApplication.run(ProjectApplication.class, args);
	}

}
