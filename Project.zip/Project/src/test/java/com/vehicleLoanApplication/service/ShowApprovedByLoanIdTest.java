package com.vehicleLoanApplication.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.vehicleloanapplication.dao.ApprovedLoansJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.AccountEntity;
import com.vehicleloanapplication.model.AdminEntity;
import com.vehicleloanapplication.model.ApprovedLoansEntity;
import com.vehicleloanapplication.model.LoanApplicationEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.service.ApprovedLoanServiceImpl;

@SpringBootTest
public class ShowApprovedByLoanIdTest {

	@BeforeEach
	public void setup() {
	}

	@MockBean
	ApprovedLoansJPARepository approvedRepo;

	@Autowired
	ApprovedLoanServiceImpl approvedService;

	@Test
	@DisplayName("Test - showApprovedByLoanId - successful")
	public void correctObjectPassed() throws RecordNotFoundException{

		int loanId = 1234;
		Optional<ApprovedLoansEntity> returned = null;

		UserDetailsEntity user =new UserDetailsEntity("SN Puram", "ANDHRA PRADESH","KAKINADA", "600073", "Full time",
				50000.0, "aadhar.url", "pan.url", "salaryslip.url", "adreesproof.url");
		AccountEntity account = new AccountEntity(100,user);

		LoanApplicationEntity loan=new LoanApplicationEntity("12ht45", 200000.0,10,5.0,5000000,
				LocalDate.now(),"APPROVED", "Mercedes", "red", "cls", 4, 5000000.0,
				6000000, user);

		ApprovedLoansEntity app = new ApprovedLoansEntity(1234,20.0,LocalDate.now(),account,loan);

		Mockito.when(approvedRepo.saveAndFlush(app)).thenReturn(app);
		Mockito.when(approvedRepo.findById(loanId)).thenReturn(Optional.of(app));

		returned = Optional.of(approvedService.showApprovedByLoanId(loanId));
		assertEquals(returned.get(),app);
	}



	@Test
	@DisplayName("Test - showApprovedByLoanId - no loanId Entered")
	public void noLoanIdEntered() {
		int loanId = 0;


		UserDetailsEntity user =new UserDetailsEntity("SN Puram", "ANDHRA PRADESH","KAKINADA", "600073", "Full time",
				50000.0, "aadhar.url", "pan.url", "salaryslip.url", "adreesproof.url");

		AccountEntity account = new AccountEntity(100,user);
		LoanApplicationEntity loan=new LoanApplicationEntity("12ht45", 200000.0,10,5.0,5000000, LocalDate.now(),"APPROVED", "Mercedes", "red", "cls", 4, 5000000, 6000000, user);
		Optional<ApprovedLoansEntity> app = Optional.of(new ApprovedLoansEntity(123,20.0,LocalDate.now(),account,loan));

		ApprovedLoansEntity returned = null;
		// Optional<ApprovedLoansEntity> app2 = null;

		Mockito.when(approvedRepo.findById(loanId)).thenReturn(app);
		try {
			returned = approvedService.showApprovedByLoanId(loanId);
		} catch (RecordNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotEquals(returned,app);

	}

	@Test
	@DisplayName("Test - showApprovedByLoanId - wrong loanId Entered")
	public void wrongLoanIdEntered()  {
		int loanId = 6789;

		UserDetailsEntity user =new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
		AccountEntity account = new AccountEntity(100,user);
		LoanApplicationEntity loan=new LoanApplicationEntity("12ht45", 200000.0,10,5.0,5000000, LocalDate.now(),"PENDING", "Mercedes", "red", "cls", 4, 5000000, 6000000, user);
		Optional<ApprovedLoansEntity> app = Optional.of(new ApprovedLoansEntity(123,20.0,LocalDate.now(),account,loan));

		ApprovedLoansEntity returned = null;
		Mockito.when(approvedRepo.findById(loanId)).thenReturn(app);
		try {
			returned = approvedService.showApprovedByLoanId(loanId);
		} catch (RecordNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotEquals(returned,app);


	}

}