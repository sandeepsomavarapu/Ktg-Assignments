package com.vehicleLoanApplication.service;

 

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.vehicleloanapplication.dao.ApprovedLoansJPARepository;
import com.vehicleloanapplication.model.AccountEntity;
import com.vehicleloanapplication.model.ApprovedLoansEntity;
import com.vehicleloanapplication.model.LoanApplicationEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.service.ApprovedLoanServiceImpl;

 


@SpringBootTest  
public class AddApprovedLoanTest {
    @MockBean
    ApprovedLoansJPARepository approvedRepo;
    @Autowired
    ApprovedLoanServiceImpl approveService;
    @Test   
   // @Disabled
    public void noDetailsFound()
    {
       ApprovedLoansEntity approve=null;
       List<ApprovedLoansEntity> approveList=new ArrayList<ApprovedLoansEntity>();
       try {
       Mockito.doReturn(approvedRepo.findAll()).when(approvedRepo).save(approve);
       approveList=approveService.addApprovedLoan(approve);
       }
       catch(Exception e)
       {
       assertEquals(e.getMessage(),"Invalid Object Found!"); 
    }
    } 
    @Test
    @DisplayName("AddApprovedLoan - If invalid status found")
    public void noStatusNotAccepted()
    {
        List<ApprovedLoansEntity> approveList=new ArrayList<ApprovedLoansEntity>();
        UserDetailsEntity user=new UserDetailsEntity("Ruby , Santhosapuram", "Andhra Pradesh","Gudivada", "6400", "Part time",
                6000000.0, "abcd.url", "hgfh.url", "salaryslips.url", "adreesproofs.url");
       LoanApplicationEntity loan=new LoanApplicationEntity("Ts03", 100000.0,20,9.0,8000000,
            LocalDate.now(),"Pending", "Indigo", "Yellow", "clsas", 8, 6000000.0,
            7000000, user);
       AccountEntity account=new AccountEntity(1234,user);
       ApprovedLoansEntity approve=new ApprovedLoansEntity(123,34.45,LocalDate.now(),account,loan);
       try {
       Mockito.doReturn(Arrays.asList(approve)).when(approvedRepo).save(approve);
       approveList=approveService.addApprovedLoan(approve); 
       }         
       catch(Exception e)
       {
       assertEquals(e.getMessage(),"Loan is still not approved!");
    }
    }
    @Test
    @DisplayName("AddApprovedLoan - If Duplicate Record found")
    public void duplicateRecordFound()
    {
        List<ApprovedLoansEntity> approveList=new ArrayList<ApprovedLoansEntity>();
        UserDetailsEntity user=new UserDetailsEntity("Ruby , Santhosapuram", "Andhra Pradesh","Gudivada", "6400", "Part time",
                6000000.0, "abcd.url", "hgfh.url", "salaryslips.url", "adreesproofs.url");
       LoanApplicationEntity loan=new LoanApplicationEntity("Ts03", 100000.0,20,9.0,8000000,
            LocalDate.now(),"Accepted", "Indigo", "Yellow", "clsas", 8, 6000000.0,                                       
            7000000, user);
       AccountEntity account=new AccountEntity(1234,user);                                                                                                                                                                                           
       ApprovedLoansEntity approve=new ApprovedLoansEntity(123,34.45,LocalDate.now(),account,loan);                                                                                                   approvedRepo.save(approve);
       try {
       Mockito.doReturn(Arrays.asList(approve)).when(approvedRepo).save(approve); 
       approveList=approveService.addApprovedLoan(approve);
       }         
       catch(Exception e)
       {
       assertSame(0,approveList.size());
    }
    }    
    @Test
    @DisplayName("AddApprovedLoan - If Record added successfully")
    public void addedSuccessfully()
    {
        List<ApprovedLoansEntity> approveList=new ArrayList<ApprovedLoansEntity>();
        UserDetailsEntity user=new UserDetailsEntity("Ruby , Santhosapuram", "Andhra Pradesh","Gudivada", "6400", "Part time",
                6000000.0, "abcd.url", "hgfh.url", "salaryslips.url", "adreesproofs.url");
       LoanApplicationEntity loan=new LoanApplicationEntity("Ts03", 100000.0,20,9.0,8000000,
            LocalDate.now(),"Accepted", "Indigo", "Yellow", "clsas", 8, 6000000.0,                                       
            7000000, user);
       AccountEntity account=new AccountEntity(1234,user);                                                                                                                                                                                           
       ApprovedLoansEntity approve=new ApprovedLoansEntity(123,34.45,LocalDate.now(),account,loan);                                                                                                   approvedRepo.save(approve);
       try {
       Mockito.doReturn(Arrays.asList(approve)).when(approvedRepo).save(approve);
       approveList=approveService.addApprovedLoan(approve);
       }                      
       catch(Exception e)
       {
      
    }
       assertNotNull(approveList);
    }    
      
}