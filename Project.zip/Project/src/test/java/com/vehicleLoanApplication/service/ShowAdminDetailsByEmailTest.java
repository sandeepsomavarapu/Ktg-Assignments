package com.vehicleLoanApplication.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

 

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

 

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

 

import com.vehicleloanapplication.dao.AdminJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.AdminEntity;
import com.vehicleloanapplication.model.LoanApplicationEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.AdminServiceImpl;

 

@SpringBootTest
public class ShowAdminDetailsByEmailTest {

 

    @BeforeEach
    public void setup() {

 

    }
    
    @MockBean
    AdminJPARepository adminRepo;
    
    @Autowired
    AdminServiceImpl adminService;
    
    @Test
    @DisplayName("Test - show admin details by email - successful")
    public void correctObjectPassed(){
        String email = "pavan@gmail.com";
        Optional<AdminEntity> adminEntity = null;
        
        AdminEntity admin = new AdminEntity("pavan@gmail.com","pavansai","1234");
        
        Mockito.when(adminRepo.saveAndFlush(admin)).thenReturn(admin);
        Mockito.when(adminRepo.findById(email)).thenReturn(Optional.of(admin));
        
        try {
            adminEntity = Optional.of(adminService.showAdminDetailsByEmail(email));
        } catch (RecordNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        assertEquals(adminEntity.get(),admin);

 

    }
    
    @Test
    @DisplayName("Show admin details by email- no email entered")
    public void noEmailEntered()  {
        
        String email = null;
        AdminEntity admin2 = null;
        Optional<AdminEntity> admin1 = null;
        
        try {
        	Mockito.when(adminRepo.findById(email)).thenReturn(admin1);
            admin2 = adminService.showAdminDetailsByEmail(email);
            assertEquals(admin1,admin2);
        } catch (RecordNotFoundException e) {
            // TODO Auto-generated catch block
        	
        }
        
        
        
    }
    
    @Test
    @DisplayName("Show admin details by email - wrong email entered")
    public void wrongEmailEntered()  {
        
        String email = "pavansai@gmail.com";
        
        AdminEntity admin = new AdminEntity("pavan@gmail.com","pavansai","1234");
        Optional<AdminEntity> admin1 = null;
        AdminEntity admin2 = null;
        Mockito.when(adminRepo.saveAndFlush(admin)).thenReturn(admin);
        Mockito.when(adminRepo.findById(email)).thenReturn(admin1);
        
        try {
            admin2 = adminService.showAdminDetailsByEmail(email);
            assertEquals(admin1,admin2);
        } catch (RecordNotFoundException e) {
           
        }
       

 

        
    }
    

 

}