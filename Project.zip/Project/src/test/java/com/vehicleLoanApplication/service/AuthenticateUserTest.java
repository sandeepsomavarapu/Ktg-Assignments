package com.vehicleLoanApplication.service;
//package com.vehicleLoanApplication.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.time.LocalDate;
import java.util.ArrayList; 
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.vehicleloanapplication.dao.UserRegisterJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.exceptions.RegistrationException;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.LoginDtoService;
@SpringBootTest
public class AuthenticateUserTest {
     
	@MockBean
	UserRegisterJPARepository userRepo;
	@Autowired
	LoginDtoService loginService;
	
	@Test
	@DisplayName("User Authentication - If Invalid User Found")
	public void invalidUserFound()
	{
		UserDetailsEntity userdetails=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
				5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
		UserRegistrationEntity user=new UserRegistrationEntity("saranya24@gmail.com",20,"Female","23567q8","saranya","password",userdetails);
	     
	     try {
	    	 Mockito.doReturn(Optional.of(user)).when(userRepo).findById("saranya@gmail.com");
	      
	    	   UserRegistrationEntity retUser=loginService.authenticateUser("saranya@gmailcom","pass");
	     }
	     catch(Exception exception)
	     {
	    	 assertEquals(exception.getMessage(),"No record exists for given user");
	     } 
	}
	@Test
	@DisplayName("User Authentication - If No Email Entered")
	public  void nullDetailsFound() throws RecordNotFoundException
	{
		UserDetailsEntity userdetails=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
				5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
		UserRegistrationEntity user=new UserRegistrationEntity("saranya",20,"Female","23567q8","saranya","password",userdetails);
	     
	       
	            Mockito.doReturn(Optional.of(user)).when(userRepo).findById("saranya@gmail.com"); 
	     
	            
					try {
						UserRegistrationEntity  retUser=(loginService.authenticateUser("","password"));
					} catch (RegistrationException | RecordNotFoundException e) {
						// TODO Auto-generated catch block   
						assertEquals(e.getMessage(),"Invalid Details! please enter correct details");
					}
				
	  }
	   
	@Test
	@DisplayName("User Authentication - If Password Incorrect for given Email")
	public  void incorrectPasswordFound() 
	{
		UserDetailsEntity userdetails=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
				5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
		UserRegistrationEntity user=new UserRegistrationEntity("saranya24@gmail.com",20,"Female","23567q8","saranya","password",userdetails);
	    
	       
	            Mockito.doReturn(Optional.of(user)).when(userRepo).findById("saranya24@gmail.com"); 
	     
	             
					try {
						UserRegistrationEntity  retUser=(loginService.authenticateUser("saranya24@gmail.com","pass"));
					} catch (RegistrationException | RecordNotFoundException e) {
						// TODO Auto-generated catch block
						assertEquals(e.getMessage(),"password does not matches");
					}
				
	}
	@Test
	@DisplayName("User Authentication - If User SignIn successful")
	public  void successfulLogin() 
	{
		UserDetailsEntity userdetails=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
				5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
		UserRegistrationEntity user=new UserRegistrationEntity("saranya24@gmail.com",20,"Female","23567q8","saranya","password",userdetails);
	    
	       
	            Mockito.doReturn(Optional.of(user)).when(userRepo).findById("saranya24@gmail.com"); 
	     
	             
					try {
						UserRegistrationEntity  retUser=(loginService.authenticateUser("saranya24@gmail.com","password"));
						assertSame(user,retUser);
					} catch (RegistrationException | RecordNotFoundException e) {
						e.printStackTrace();
					}
			
				
	}
	 
}