package com.vehicleLoanApplication.service;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.vehicleloanapplication.dao.LoanApplicationJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.LoanApplicationEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.LoanApplicationServiceImpl;


@SpringBootTest
public class ModifyLoanApplicationStatusTest {
	


@MockBean
LoanApplicationJPARepository loanRepo;
			
@Autowired
LoanApplicationServiceImpl loanService;

//Modify Loan Application Status Successful
@Test
@DisplayName("Modify Loan Application Status- successful")
public void loanApplicationByEmailSuccessfull() throws RecordNotFoundException {
	List<LoanApplicationEntity> list=new ArrayList<LoanApplicationEntity>();
	UserDetailsEntity user=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
			5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
	
	LoanApplicationEntity loan=new LoanApplicationEntity("12ht46", 200000.0,10,5.0,5000000,
			LocalDate.now(),"PENDING", "Mercedes", "red", "cls", 4, 5000000.0,
			6000000, user);
	
	Mockito.when(loanRepo.findAll()).thenReturn(Arrays.asList(loan));
	list=loanService.modifyLoanApplicationStatus(loan);
    assertEquals(list.size(),1);	
	
}

//loan not found
@Test
@DisplayName("Modify Loan Application Status - loan not found")
public void noLoanApplicationFound()  {
	
	List<LoanApplicationEntity> list=new ArrayList<LoanApplicationEntity>();
	
	List<LoanApplicationEntity> returnedList=new ArrayList<LoanApplicationEntity>();
	
	LoanApplicationEntity loan=new LoanApplicationEntity("12kk46", 200000.0,10,5.0,5000000,
			LocalDate.now(),"PENDING", "Mercedes", "red", "cls", 4, 5000000.0,
			6000000, null);
	
	Mockito.when(loanRepo.findById("12kk46")).thenReturn(null);
	try {
		Mockito.when(loanRepo.findAll()).thenReturn(list);
		returnedList=loanService.modifyLoanApplicationStatus(loan);
	} catch (RecordNotFoundException e) {
		assertEquals(e.getMessage(),"Loan Application Not Found");	
	}
    
	
}

//null object passed
@Test
@DisplayName("Modify Loan Application Status - null object passed")
public void nullObjectPassed() {
	
	List<LoanApplicationEntity> list=new ArrayList<LoanApplicationEntity>();
	List<LoanApplicationEntity> returnedList=new ArrayList<LoanApplicationEntity>();
	LoanApplicationEntity loan=null;
	
	try {
		Mockito.when(loanRepo.findAll()).thenReturn(list);
		returnedList=loanService.modifyLoanApplicationStatus(loan);
	} catch (Exception e) {
		assertEquals(e.getMessage(),"Loan Application Not Found");
	}
    
	
}
}

