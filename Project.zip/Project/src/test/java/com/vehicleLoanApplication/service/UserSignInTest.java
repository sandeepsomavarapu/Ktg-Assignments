package com.vehicleLoanApplication.service;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;


import java.util.Optional;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.vehicleloanapplication.dao.UserRegisterJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.exceptions.RegistrationException;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.LoginDtoService;
@SpringBootTest
public class UserSignInTest {
     
	@MockBean
	UserRegisterJPARepository userRepo; 
	@Autowired
	LoginDtoService loginService;
	
	@Test
	@DisplayName("UserAuthentication - If Invalid User Found")
	public void invalidUserFound()
	{
	         Optional<UserRegistrationEntity> mockUser = null;
	         UserRegistrationEntity  retUser=null;
	     try {
	    	 Mockito.doReturn(Optional.of(mockUser)).when(userRepo).findById("saranya@gmail.com");
	      
	    	                  
				
				 retUser=loginService.authenticateUser("saranya@gmailcom","pass");
				
			
	     }
	     catch(Exception exception) 
	     {   
	    	 assertNull(retUser);    
	   
	     }
	}     
	@Test
	@DisplayName("User Authentication - If No Email Entered")  
	public  void nullDetailsFound() throws RecordNotFoundException  
	{
		    UserRegistrationEntity user=null;
	     
	         try {
	            Mockito.doReturn(Optional.of(user)).when(userRepo).findById("saranya@gmail.com"); 
						UserRegistrationEntity  retUser=(loginService.authenticateUser("","password"));assertEquals(user,retUser);
					} catch (Exception e) {  
						// TODO Auto-generated catch block   
						assertNotNull(e);
					}
				
	  }
	          
	@Test
	@DisplayName("User Authentication - If Password Incorrect for given Email")
	public  void incorrectPasswordFound() 
	{
		UserDetailsEntity userdetails=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
				5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
		UserRegistrationEntity user=new UserRegistrationEntity("saranya24@gmail.com",20,"Female","23567q8","saranya","password",userdetails);
	    
	       
	            Mockito.doReturn(Optional.of(user)).when(userRepo).findById("saranya24@gmail.com"); 
	     
	             
					try {
						UserRegistrationEntity  retUser=(loginService.authenticateUser("saranya24@gmail.com","pass"));
					} catch (RegistrationException | RecordNotFoundException e) {
						// TODO Auto-generated catch block
						assertEquals(e.getMessage(),"password does not matches");
					}
				
	}
	@Test
	@DisplayName("User Authentication - If User SignIn suucessful")
	public  void successfulLogin() 
	{
		UserDetailsEntity userdetails=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
				5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
		UserRegistrationEntity user=new UserRegistrationEntity("saranya24@gmail.com",20,"Female","23567q8","saranya","password",userdetails);
	    
	       
	            Mockito.doReturn(Optional.of(user)).when(userRepo).findById("saranya24@gmail.com"); 
	     
	             
					try {
						UserRegistrationEntity  retUser=(loginService.authenticateUser("saranya24@gmail.com","password"));
						assertSame(user,retUser);
					} catch (RegistrationException | RecordNotFoundException e) {
						e.printStackTrace();
					}
			 
				
	}    
	 
}